public class FailedProcedureException extends Exception {
    public FailedProcedureException(String msj) {
        super(msj);
    }
}
